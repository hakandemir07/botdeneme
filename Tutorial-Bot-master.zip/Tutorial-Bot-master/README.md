# Tutorial-Bot
This is the bot we're creating in the video series, each branch represents an episode, master will always be _episode 1_
![Episodic Branches](http://i.imgur.com/PoeF3fc.gif)

## Update schedule
The repo get's updated 2 days after the public release of the episode.
